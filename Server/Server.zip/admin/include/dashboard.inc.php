<?php

class Dashboard
{
}